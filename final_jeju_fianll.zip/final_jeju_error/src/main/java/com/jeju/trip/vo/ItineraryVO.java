package com.jeju.trip.vo;

import lombok.Data;

@Data
public class ItineraryVO {

	private Long iseq;
	private String id;
	private String title;
	
}
